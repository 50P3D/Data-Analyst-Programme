This folder will be a vanilla implementation of XGBoost 

Using the following params

Ive picked a few features, tire temp, race type , intial grid positions, car team , map?

Predicting the final grid positions 
+- 3 pos acceptable?


